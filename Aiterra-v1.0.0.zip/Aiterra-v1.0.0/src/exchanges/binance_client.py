import logging
from datetime import datetime
from typing import Dict, List, Optional

import ccxt.async_support as ccxt

from .base import Balance, BaseExchange, OHLCV, Order, Ticker
from ..core.config import settings

logger = logging.getLogger(__name__)


class BinanceExchange(BaseExchange):
    name = "binance"

    def __init__(self):
        cfg = settings.get("exchanges", "binance") or {}
        self._client = ccxt.binance({
            "apiKey": cfg.get("api_key", ""),
            "secret": cfg.get("api_secret", ""),
            "enableRateLimit": True,
            "options": {"defaultType": "spot"},
        })
        if cfg.get("testnet"):
            self._client.set_sandbox_mode(True)

    async def close(self):
        await self._client.close()

    async def get_ticker(self, symbol: str) -> Ticker:
        data = await self._client.fetch_ticker(symbol)
        return Ticker(
            symbol=symbol,
            price=float(data["last"]),
            change_24h=float(data.get("percentage") or 0),
            volume_24h=float(data.get("quoteVolume") or 0),
            high_24h=float(data.get("high") or 0),
            low_24h=float(data.get("low") or 0),
        )

    async def get_ohlcv(self, symbol: str, timeframe: str = "5m", limit: int = 100) -> List[OHLCV]:
        data = await self._client.fetch_ohlcv(symbol, timeframe, limit=limit)
        return [
            OHLCV(datetime.fromtimestamp(row[0] / 1000), row[1], row[2], row[3], row[4], row[5])
            for row in data
        ]

    async def get_balance(self) -> Dict[str, Balance]:
        data = await self._client.fetch_balance()
        return {
            cur: Balance(cur, float(v["free"]), float(v["used"]), float(v["total"]))
            for cur, v in data["total"].items()
            if float(v) > 0
        }

    async def create_order(self, symbol: str, side: str, amount: float, price: Optional[float] = None) -> Order:
        fn = self._client.create_market_buy_order if side == "buy" else self._client.create_market_sell_order
        data = await fn(symbol, amount)
        return Order(
            id=str(data["id"]),
            symbol=symbol,
            side=side,
            type=data.get("type", "market"),
            price=float(data.get("price") or data.get("average") or 0),
            amount=float(data["amount"]),
            cost=float(data.get("cost") or 0),
            status=data.get("status", "closed"),
        )
