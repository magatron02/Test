@echo off
title Aiterra - Restart
color 0E

echo.
echo  ============================================================
echo   Aiterra v1.0.14  --  Restarting...
echo  ============================================================
echo.

call STOP.bat
timeout /t 3 /nobreak >nul
call START.bat
