import asyncio
import copy
import csv
import io
import logging
import math
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import numpy as np
from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from ..core.config import settings
from ..core.database import ModelVersion, Portfolio, Trade, TrainingRecord, get_db, SessionLocal
from .websocket import get_notifications, clear_notifications
from ..notifications import line_notify, telegram_notify

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api")

# Whitelist of (section → allowed keys) for POST /api/settings.
# The 'app' section is intentionally absent — api_token must never be writable via API.
_SETTINGS_WHITELIST: Dict[str, set] = {
    "trading": {
        "take_profit_pct", "stop_loss_pct", "min_confidence",
        "analysis_interval", "risk_per_trade_pct", "max_daily_loss_pct",
        "max_open_trades",
    },
    "ai": {"default_model", "claude"},
    "exchanges": {"binance", "binance_th", "bitkub", "okx", "demo"},
    "notifications": {"line", "telegram", "notify_on"},
}

# For nested dict values, further restrict which sub-keys may be written.
_NESTED_KEY_WHITELIST: Dict[str, Dict[str, set]] = {
    "ai": {
        "claude": {"api_key", "model"},
    },
    "exchanges": {
        "binance":    {"api_key", "api_secret", "enabled", "testnet"},
        "binance_th": {"api_key", "api_secret", "enabled"},
        "bitkub":     {"api_key", "api_secret", "enabled"},
        "okx":        {"api_key", "api_secret", "passphrase", "enabled", "testnet"},
        "demo":       {"enabled", "data_source", "virtual_balance_usdt", "virtual_balance_thb"},
    },
    "notifications": {
        "line":      {"channel_id", "channel_secret", "user_id", "enabled"},
        "telegram":  {"bot_token", "chat_id", "enabled"},
        "notify_on": {"trade_open", "trade_close", "stop_loss", "take_profit", "training_complete"},
    },
}

# Reference to trader injected at startup
_trader = None
_training_loop = None
_hourly_trainer = None
_chat_lock: Optional[asyncio.Lock] = None


def _get_chat_lock() -> asyncio.Lock:
    """Lazy-initialise the chat lock inside the running event loop."""
    global _chat_lock
    if _chat_lock is None:
        _chat_lock = asyncio.Lock()
    return _chat_lock


# ── Auth ───────────────────────────────────────────────────────
async def _require_auth(x_api_token: str = Header(default="", alias="X-API-Token")):
    """Dependency: require a valid X-API-Token on mutating endpoints."""
    if x_api_token != settings.api_token:
        raise HTTPException(status_code=401, detail="Unauthorized — invalid or missing X-API-Token")

_AUTH = Depends(_require_auth)


@router.get("/auth/token")
async def get_auth_token():
    """Return the local API token for the in-browser frontend.
    External sites can't read this response due to the browser same-origin policy.
    """
    return {"token": settings.api_token}


def set_trader(trader):
    global _trader
    _trader = trader


def set_training_loop(loop):
    global _training_loop
    _training_loop = loop


def set_hourly_trainer(ht):
    global _hourly_trainer
    _hourly_trainer = ht


@router.get("/status")
async def get_status():
    return {
        "mode": settings.trading_mode,
        "ai_model": settings.ai_model,
        "symbols": settings.symbols,
        "running": _trader._running if _trader else False,
        "open_trades": len(_trader.open_trades) if _trader else 0,
    }


@router.get("/prices")
async def get_prices():
    if not _trader:
        return {}
    return {
        sym: {
            "price": a.price,
            "change_24h": a.change_24h,
            "rsi": a.rsi,
            "signal": a.overall_signal,
            "signal_strength": a.signal_strength,
        }
        for sym, a in _trader.analyses.items()
    }


@router.get("/portfolio")
async def get_portfolio():
    if not _trader:
        raise HTTPException(503, "Trader not running")
    # Quote currency (USDT for global exchanges, THB for Bitkub / Binance TH)
    quote = _trader._exchange.quote_currency
    try:
        balances = await _trader._exchange.get_balance()
        analyses = _trader.analyses
        positions = []
        total_value = 0.0

        cash_bal = balances.get(quote)
        cash = float(cash_bal.free) if cash_bal else 0.0
        total_value += cash

        for sym, analysis in analyses.items():
            base = sym.split("/")[0]
            bal = balances.get(base)
            if bal and bal.total > 0:
                value = bal.total * analysis.price
                total_value += value
                entry = _trader.open_trades.get(sym, {}).get("price", analysis.price)
                positions.append({
                    "symbol": sym,
                    "amount": bal.total,
                    "price": analysis.price,
                    "value": value,
                    "entry_price": entry,
                    "pnl_pct": (analysis.price - entry) / entry * 100 if entry > 0 else 0,
                })

        return {
            "cash_usdt": cash,        # kept for UI back-compat; holds `quote` balance
            "quote_currency": quote,
            "total_value": total_value,
            "positions": positions,
            "is_demo": _trader._exchange.is_demo,
        }
    except Exception as e:
        # In live mode a transient API/auth error shouldn't blank the dashboard.
        logger.warning(f"Portfolio fetch failed ({_trader._exchange.name}): {e}")
        return {
            "cash_usdt": 0.0,
            "quote_currency": quote,
            "total_value": 0.0,
            "positions": [],
            "is_demo": _trader._exchange.is_demo,
            "error": str(e)[:160],
        }


@router.get("/trades")
async def get_trades(limit: int = 50, db: Session = Depends(get_db)):
    trades = db.query(Trade).order_by(Trade.opened_at.desc()).limit(limit).all()
    return [
        {
            "id": t.id,
            "symbol": t.symbol,
            "side": t.side,
            "price": t.price,
            "amount": t.amount,
            "cost": t.cost,
            "status": t.status,
            "strategy": t.strategy,
            "ai_model": t.ai_model,
            "confidence": t.confidence,
            "reasoning": t.reasoning,
            "close_price": t.close_price,
            "pnl": t.pnl,
            "pnl_pct": t.pnl_pct,
            "mode": t.mode,
            "opened_at": t.opened_at.isoformat() if t.opened_at else None,
            "closed_at": t.closed_at.isoformat() if t.closed_at else None,
        }
        for t in trades
    ]


@router.get("/stats")
async def get_stats(db: Session = Depends(get_db)):
    closed = db.query(Trade).filter(Trade.status == "closed").all()
    if not closed:
        return {"total_trades": 0, "win_rate": 0, "avg_pnl_pct": 0, "total_pnl": 0}

    wins = [t for t in closed if (t.pnl or 0) > 0]
    total_pnl = sum(t.pnl or 0 for t in closed)
    avg_pnl_pct = sum(t.pnl_pct or 0 for t in closed) / len(closed)

    return {
        "total_trades": len(closed),
        "win_rate": len(wins) / len(closed) * 100,
        "avg_pnl_pct": avg_pnl_pct,
        "total_pnl": total_pnl,
        "best_trade": max((t.pnl_pct or 0) for t in closed),
        "worst_trade": min((t.pnl_pct or 0) for t in closed),
    }


@router.get("/dashboard/state")
async def get_dashboard_state():
    """GET /api/dashboard/state — signal funnel, today's PnL, and AI agent activity."""
    if not _trader:
        return {
            "funnel": {"analyzed": 0, "signals": 0, "approved": 0, "rejected": 0},
            "pnl_today": {"realized": 0, "floating": 0, "total": 0},
            "agents": {}, "last_signal": None, "open_positions": 0,
        }
    return await _trader.get_dashboard_state()


@router.get("/signals/market")
async def get_market_signals():
    """GET /api/signals/market — Fear & Greed index + funding rates (cached 1 h)."""
    from ..agent.market_signals import get_fear_greed, get_funding_rates, cache_status
    symbols = settings.symbols
    fg, fr = await get_fear_greed(), await get_funding_rates(symbols)
    return {
        "fear_greed": fg,
        "funding_rates": fr,
        "cache": cache_status(),
        "ext_signals": _trader._ext_signals if _trader else {},
    }


@router.get("/training")
async def get_training_stats():
    if not _trader:
        raise HTTPException(503, "Trader not running")
    return _trader.trainer_stats


@router.post("/training/trigger")
async def trigger_training(_=_AUTH):
    if not _trader:
        raise HTTPException(503, "Trader not running")
    success = _trader._trainer.train()
    return {"success": success, "stats": _trader.trainer_stats}


@router.get("/ai/model/history")
async def get_model_history(limit: int = 30):
    if not _trader:
        raise HTTPException(503, "Trader not running")
    return _trader._trainer.model_history(limit=limit)


@router.get("/settings")
async def get_settings():
    # Deep copy — a shallow copy shares the nested dicts with settings._cfg, so
    # masking below would overwrite the real in-memory keys with "****" and a
    # later settings.save() would persist that corruption (losing saved API keys).
    cfg = copy.deepcopy(settings._cfg)
    # mask API keys
    for ex in cfg.get("exchanges", {}).values():
        if isinstance(ex, dict):
            if "api_key" in ex and ex["api_key"]:
                ex["api_key"] = ex["api_key"][:4] + "****"
            if "api_secret" in ex and ex["api_secret"]:
                ex["api_secret"] = "****"
    if "ai" in cfg and "claude" in cfg["ai"]:
        key = cfg["ai"]["claude"].get("api_key", "")
        cfg["ai"]["claude"]["api_key"] = key[:8] + "****" if key else ""
    # Never expose the auth token in the settings dump. The frontend reads it
    # via the same-origin GET /api/auth/token endpoint instead.
    if isinstance(cfg.get("app"), dict) and cfg["app"].get("api_token"):
        cfg["app"]["api_token"] = "****"
    return cfg


@router.post("/settings")
async def update_settings(data: Dict[str, Any], _=_AUTH):
    for section, values in data.items():
        if section not in _SETTINGS_WHITELIST:
            raise HTTPException(400, f"Section '{section}' cannot be modified via this endpoint")
        if not isinstance(values, dict):
            continue
        allowed_keys = _SETTINGS_WHITELIST[section]
        for key, val in values.items():
            if key not in allowed_keys:
                raise HTTPException(400, f"Key '{section}.{key}' cannot be modified via this endpoint")
            if isinstance(val, dict) and section in _NESTED_KEY_WHITELIST and key in _NESTED_KEY_WHITELIST[section]:
                allowed_sub = _NESTED_KEY_WHITELIST[section][key]
                existing = settings.get(section, key) or {}
                filtered = {sk: sv for sk, sv in val.items() if sk in allowed_sub}
                settings.set({**existing, **filtered}, section, key)
            else:
                settings.set(val, section, key)
    settings.save()
    settings.reload()
    return {"success": True}


@router.post("/mode")
async def set_mode(data: Dict[str, str], _=_AUTH):
    mode = data.get("mode", "demo")
    if mode not in ("demo", "live"):
        raise HTTPException(400, "Mode must be 'demo' or 'live'")
    settings.set(mode, "trading", "mode")
    settings.save()
    return {"mode": mode}


@router.post("/strategy")
async def set_strategy(data: Dict[str, str], _=_AUTH):
    strategy = data.get("strategy", "hybrid")
    if strategy not in ("dca", "trend", "mean_reversion", "hybrid"):
        raise HTTPException(400, "Invalid strategy")
    settings.set(strategy, "strategy", "primary")
    settings.save()
    return {"strategy": strategy}


@router.post("/ai-model")
async def set_ai_model(data: Dict[str, str], _=_AUTH):
    model = data.get("model", "hybrid")
    valid = ("claude", "rule_based", "ml", "hybrid")
    if model not in valid:
        raise HTTPException(400, f"Model must be one of {valid}")
    settings.set(model, "ai", "default_model")
    settings.save()
    return {"model": model}


@router.post("/demo/reset")
async def reset_demo(_=_AUTH):
    if not _trader or not _trader._exchange.is_demo:
        raise HTTPException(400, "Not in demo mode")
    _trader._exchange.reset()
    _trader._open_trades.clear()
    return {"success": True}


@router.get("/trades/export")
async def export_trades(db: Session = Depends(get_db)):
    """GET /api/trades/export — Download all trades as CSV."""
    trades = db.query(Trade).order_by(Trade.opened_at.desc()).all()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["id", "symbol", "side", "price", "amount", "cost", "mode",
                     "exchange", "strategy", "ai_model", "confidence", "status",
                     "close_price", "pnl", "pnl_pct", "opened_at", "closed_at"])
    for t in trades:
        writer.writerow([
            t.id, t.symbol, t.side, t.price, t.amount, t.cost, t.mode,
            t.exchange, t.strategy, t.ai_model, t.confidence, t.status,
            t.close_price, t.pnl, t.pnl_pct,
            t.opened_at.isoformat() if t.opened_at else "",
            t.closed_at.isoformat() if t.closed_at else "",
        ])
    buf.seek(0)
    filename = f"trades_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.get("/stats/advanced")
async def get_advanced_stats(db: Session = Depends(get_db)):
    """GET /api/stats/advanced — Sharpe ratio, Max Drawdown, daily PnL."""
    closed = db.query(Trade).filter(Trade.status == "closed").order_by(Trade.closed_at).all()
    if len(closed) < 2:
        return {"sharpe": 0, "max_drawdown_pct": 0, "daily_pnl": [], "equity_curve": []}

    # Cumulative equity from trades (start at 10000 for display)
    capital = 10000.0
    equity  = [capital]
    for t in closed:
        pnl = t.pnl or 0
        capital += pnl
        equity.append(round(capital, 2))

    eq = np.array(equity, dtype=float)
    rets = np.diff(eq) / np.where(eq[:-1] != 0, eq[:-1], 1)

    # Annualize using the actual average time between consecutive trade closes
    # rather than a fixed 252-trading-day assumption.
    trade_dates = [t.closed_at for t in closed if t.closed_at]
    if len(trade_dates) >= 2:
        span_days = (max(trade_dates) - min(trade_dates)).total_seconds() / 86400
        avg_days_per_obs = span_days / max(len(trade_dates) - 1, 1)
        ann_factor = math.sqrt(365 / avg_days_per_obs) if avg_days_per_obs > 0 else math.sqrt(252)
    else:
        ann_factor = math.sqrt(252)
    sharpe = float((rets.mean() / rets.std()) * ann_factor) if rets.std() > 0 else 0.0

    run_max = np.maximum.accumulate(eq)
    max_dd  = float(((eq - run_max) / np.where(run_max != 0, run_max, 1)).min() * 100)

    # Daily PnL aggregation
    from collections import defaultdict
    daily: dict = defaultdict(float)
    for t in closed:
        if t.closed_at:
            day = t.closed_at.strftime("%Y-%m-%d")
            daily[day] += t.pnl or 0
    daily_pnl = [{"date": d, "pnl": round(v, 2)} for d, v in sorted(daily.items())]

    # Use portfolio snapshots for equity curve if available (better than trade-based)
    snapshots = db.query(Portfolio).order_by(Portfolio.recorded_at).all()
    if len(snapshots) >= 2:
        equity_curve = [{"t": s.recorded_at.isoformat(), "v": round(s.total_value_usdt, 2)}
                        for s in snapshots]
        eq_snap = np.array([s.total_value_usdt for s in snapshots])
        run_max_snap = np.maximum.accumulate(eq_snap)
        max_dd = float(((eq_snap - run_max_snap) / np.where(run_max_snap != 0, run_max_snap, 1)).min() * 100)
        rets_snap = np.diff(eq_snap) / np.where(eq_snap[:-1] != 0, eq_snap[:-1], 1)
        if rets_snap.std() > 0:
            # Annualize from the actual average snapshot interval
            snap_dates = [s.recorded_at for s in snapshots if s.recorded_at]
            if len(snap_dates) >= 2:
                snap_span = (max(snap_dates) - min(snap_dates)).total_seconds() / 86400
                snap_avg  = snap_span / max(len(snap_dates) - 1, 1)
                snap_ann  = math.sqrt(365 / snap_avg) if snap_avg > 0 else math.sqrt(252 * 288)
            else:
                snap_ann = math.sqrt(252 * 288)
            sharpe = float((rets_snap.mean() / rets_snap.std()) * snap_ann)
    else:
        equity_curve = [{"i": i, "v": v} for i, v in enumerate(equity)]

    return {
        "sharpe":           round(sharpe, 2),
        "max_drawdown_pct": round(max_dd, 2),
        "daily_pnl":        daily_pnl,
        "equity_curve":     equity_curve,
    }


@router.get("/candles")
async def get_candles(symbol: str = "BTC/USDT", limit: int = 80, timeframe: str = "15m"):
    """GET /api/candles?symbol=BTC/USDT&limit=80&timeframe=15m — OHLCV for candlestick chart."""
    if not _trader:
        raise HTTPException(503, "Trader not running")
    try:
        candles = await _trader._exchange.get_ohlcv(symbol, timeframe=timeframe, limit=limit)
        return [
            {"t": int(c.timestamp.timestamp() * 1000),
             "o": c.open, "h": c.high, "l": c.low, "c": c.close, "v": c.volume}
            for c in candles
        ]
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/analysis/mtf")
async def get_mtf_analysis(symbol: str = "BTC/USDT"):
    """GET /api/analysis/mtf — Multi-timeframe analysis (15m + 1h + 4h)."""
    if not _trader:
        raise HTTPException(503, "Trader not running")
    from ..agent.market_analyzer import analyze

    async def _tf(tf: str, limit: int):
        try:
            candles = await _trader._exchange.get_ohlcv(symbol, timeframe=tf, limit=limit)
            ticker  = await _trader._exchange.get_ticker(symbol)
            result  = analyze(symbol, candles, ticker.price, ticker.change_24h)
            return {
                "timeframe":  tf,
                "signal":     result.overall_signal,
                "confidence": round(result.signal_strength, 2),
                "rsi":        round(result.rsi, 1),
                "ema_trend":  result.ema_trend,
                "macd_trend": result.macd_trend,
                "bb_signal":  result.bb_signal,
            }
        except Exception:
            return {"timeframe": tf, "signal": "HOLD", "confidence": 0,
                    "rsi": 50, "ema_trend": "NEUTRAL", "macd_trend": "NEUTRAL", "bb_signal": "NEUTRAL"}

    results = {}
    for tf, limit in [("15m", 80), ("1h", 80), ("4h", 60)]:
        results[tf] = await _tf(tf, limit)

    # Weighted combined signal (15m:0.3, 1h:0.4, 4h:0.3)
    weights = {"15m": 0.3, "1h": 0.4, "4h": 0.3}
    buy_score = sell_score = 0.0
    for tf, w in weights.items():
        sig = results[tf]["signal"]
        conf = results[tf]["confidence"]
        if sig == "BUY":   buy_score  += w * conf
        elif sig == "SELL": sell_score += w * conf

    if buy_score > sell_score and buy_score >= 0.25:
        combined = "BUY"
        combined_conf = round(buy_score, 2)
    elif sell_score > buy_score and sell_score >= 0.25:
        combined = "SELL"
        combined_conf = round(sell_score, 2)
    else:
        combined = "HOLD"
        combined_conf = round(max(buy_score, sell_score), 2)

    return {
        "symbol":           symbol,
        "timeframes":       results,
        "combined_signal":  combined,
        "combined_conf":    combined_conf,
    }


# ─── Training Loop Routes ──────────────────────────────────────

@router.post("/training/loop/start")
async def start_training_loop(data: Dict[str, Any] = None, _=_AUTH):
    if not _training_loop:
        raise HTTPException(503, "Training loop not available")
    d = data or {}
    target     = float(d.get("target", 0.80))
    auto_trade = bool(d.get("auto_trade", False))
    await _training_loop.start(target=target, auto_trade=auto_trade)
    return {"started": True, "target": target, "auto_trade": auto_trade}


@router.get("/training/loop/status")
async def get_training_loop_status():
    if not _training_loop:
        return {"running": False, "completed": False, "total_trades": 0, "win_rate": 0.0}
    return _training_loop.status


# ─── Notification History ──────────────────────────────────────

@router.get("/notifications")
async def get_notification_history():
    """GET /api/notifications — recent trade/training events (newest first)."""
    return get_notifications()


@router.delete("/notifications")
async def clear_notification_history():
    """DELETE /api/notifications — clear the notification log."""
    clear_notifications()
    return {"cleared": True}


# ─── Live Positions (enriched open trades) ────────────────────

@router.get("/positions")
async def get_open_positions():
    """GET /api/positions — open trades enriched with current price and floating PnL."""
    if not _trader:
        return []
    rows = []
    for sym, trade in list(_trader.open_trades.items()):
        analysis = _trader.analyses.get(sym)
        cur_price = analysis.price if analysis else trade["price"]
        entry     = trade["price"]
        amount    = trade.get("amount", 0)
        floating  = (cur_price - entry) * amount
        pnl_pct   = (cur_price - entry) / entry * 100 if entry > 0 else 0.0
        rows.append({
            "symbol":         sym,
            "side":           trade.get("side", "BUY"),
            "entry_price":    round(entry, 6),
            "current_price":  round(cur_price, 6),
            "amount":         round(amount, 6),
            "cost":           round(trade.get("cost", 0), 2),
            "floating_pnl":   round(floating, 4),
            "pnl_pct":        round(pnl_pct, 2),
            "stop_loss":      round(trade.get("stop_loss_price", 0), 6),
            "take_profit":    round(trade.get("take_profit_price", 0), 6),
            "strategy":       trade.get("strategy", ""),
            "confidence":     round(trade.get("confidence", 0), 2),
            "opened_at":      trade["opened_at"].isoformat() if isinstance(trade.get("opened_at"), datetime) else trade.get("opened_at"),
        })
    return rows


@router.post("/trade/manual")
async def manual_trade(data: Dict[str, Any], _=_AUTH):
    """POST /api/trade/manual — manually open or close a position (demo-safe override).
    Body: {"action":"BUY"|"SELL"|"CLOSE", "symbol":"BTC/USDT", "amount_usdt": 200}
    Bypasses the AI signal so users can test the full trade pipeline.
    """
    if not _trader:
        raise HTTPException(503, "Trader not running")
    action  = (data.get("action") or "").upper()
    symbol  = data.get("symbol") or "BTC/USDT"
    amt_usdt = float(data.get("amount_usdt") or 0)
    if action not in ("BUY", "SELL", "CLOSE"):
        raise HTTPException(400, "action must be BUY, SELL, or CLOSE")

    analysis = await _trader.analyze_symbol(symbol)
    if not analysis:
        raise HTTPException(503, f"Cannot fetch data for {symbol}")

    if action == "CLOSE":
        if symbol not in _trader.open_trades:
            raise HTTPException(400, f"No open trade for {symbol}")
        trade = _trader.open_trades[symbol]
        price = analysis.price
        amount = trade.get("amount", 0)
        # The bot only opens long (BUY) positions and _close_trade always sells
        # the base balance, so PnL is always computed long-close.
        pnl   = (price - trade["price"]) * amount
        pnl_pct = pnl / (trade["price"] * amount) * 100 if trade["price"] and amount else 0
        result = await _trader._close_trade(symbol, price, "manual_close")
        if not result:
            raise HTTPException(500, "Close failed: position may have already been liquidated")
        return {"ok": True, "action": "CLOSE", "symbol": symbol,
                "price": round(result.get("price", price), 6),
                "pnl": round(result.get("pnl", pnl), 4),
                "pnl_pct": round(result.get("pnl_pct", pnl_pct), 2)}

    # BUY / SELL
    from ..agent.strategy_manager import TradingSignal
    portfolio = await _trader._get_portfolio_summary()
    avail = portfolio.get("available_usdt", 0)
    if amt_usdt <= 0:
        # default: 10% of portfolio, capped at available
        amt_usdt = min(avail * 0.10, avail * 0.95)
    if amt_usdt <= 0:
        raise HTTPException(400, "Insufficient funds for manual trade")
    amount = amt_usdt / analysis.price
    signal = TradingSignal(action=action, confidence=1.0,
                           reasoning="manual override",
                           strategy="manual",
                           stop_loss_pct=0.02,
                           take_profit_pct=0.04)
    executed = await _trader._execute_trade(symbol, signal, analysis, force=True)
    if executed:
        return {"ok": True, "action": action, "symbol": symbol,
                "price": round(analysis.price, 6), "amount": round(amount, 6),
                "amount_usdt": round(amt_usdt, 2)}
    return {"ok": False, "reason": "execute returned False (risk limit / existing position / demo error)"}


@router.post("/training/loop/stop")
async def stop_training_loop(_=_AUTH):
    if not _training_loop:
        raise HTTPException(503, "Training loop not available")
    _training_loop.stop()
    return {"stopped": True}


@router.get("/training/hourly/status")
async def hourly_train_status():
    """GET /api/training/hourly/status — hourly real-data trainer status."""
    if not _hourly_trainer:
        return {"enabled": False}
    return {"enabled": True, **_hourly_trainer.status}


@router.post("/training/hourly/run")
async def hourly_train_run(_=_AUTH):
    """POST /api/training/hourly/run — trigger an immediate training run."""
    if not _hourly_trainer:
        raise HTTPException(503, "Hourly trainer not available")
    result = await _hourly_trainer.run_now()
    return result


# ─── Chat Bot ──────────────────────────────────────────────────

class ChatHandler:
    """
    Smart chat handler with Claude-powered intent routing and tool use.

    Fast-path keywords handle obvious commands without API calls.
    For ambiguous or open-ended messages, Claude is invoked with:
      - Live market data for all tracked symbols
      - AI model version and accuracy stats
      - Recent trade history
      - Conversation memory (last N turns)
      - Tools: analyze_symbol, get_portfolio, get_performance_report
    """

    # Extended symbol map — full English names + Thai names
    _SYMBOL_MAP: Dict[str, str] = {
        "btc": "BTC/USDT",   "bitcoin": "BTC/USDT",    "บิทคอยน์": "BTC/USDT",
        "บิท": "BTC/USDT",
        "eth": "ETH/USDT",   "ethereum": "ETH/USDT",   "อีเธอร์": "ETH/USDT",
        "อีเธอ": "ETH/USDT",
        "bnb": "BNB/USDT",   "binance coin": "BNB/USDT",
        "sol": "SOL/USDT",   "solana": "SOL/USDT",     "โซลาน่า": "SOL/USDT",
        "โซล": "SOL/USDT",
        "xrp": "XRP/USDT",   "ripple": "XRP/USDT",     "ริปเปิล": "XRP/USDT",
    }

    # Conversation history — class-level, shared across requests (single-user app)
    _history: List[Dict] = []
    MAX_HISTORY = 12        # keep last 12 messages (6 full turns)
    MAX_TOOL_STEPS = 3      # max tool-call rounds per request

    # Fast-path keyword sets (only very obvious, unambiguous patterns)
    _TRAIN_KW    = {"train", "เทรน", "retrain", "ฝึก", "เรียน", "improve model", "อัพเดต model"}
    _REPORT_KW   = {"รายงานผล", "สรุปผล", "ดูผล", "win rate", "pnl report", "performance report"}
    _PORTFOLIO_KW = {"พอร์ตฉัน", "ดูพอร์ต", "my portfolio", "my balance", "ยอดเงินฉัน"}
    _BUY_KW      = {"ซื้อ ", "buy btc", "buy eth", "buy sol", "buy bnb", "buy xrp", "long "}
    _SELL_KW     = {"ขาย ", "sell btc", "sell eth", "sell sol", "sell bnb", "sell xrp", "short "}
    _ANALYZE_KW  = {"วิเคราะห์ ", "analyze ", "analysis of"}

    def __init__(self, trader, hourly_trainer):
        self._trader = trader
        self._hourly_trainer = hourly_trainer

    def _extract_symbol(self, text: str) -> Optional[str]:
        """Extract trading pair, checking longest keys first to avoid substring collisions."""
        for key in sorted(self._SYMBOL_MAP, key=len, reverse=True):
            if key in text:
                return self._SYMBOL_MAP[key]
        return None

    def _fast_intent(self, m: str) -> Optional[str]:
        if any(kw in m for kw in self._TRAIN_KW):      return "train"
        if any(kw in m for kw in self._REPORT_KW):     return "report"
        if any(kw in m for kw in self._PORTFOLIO_KW):  return "portfolio"
        if any(kw in m for kw in self._ANALYZE_KW):    return "analyze"
        if any(kw in m for kw in self._BUY_KW):        return "buy"
        if any(kw in m for kw in self._SELL_KW):       return "sell"
        return None

    async def handle(self, message: str) -> dict:
        m = message.lower().strip()
        symbol = self._extract_symbol(m)
        intent = self._fast_intent(m)

        if intent == "train":     return await self._handle_train()
        if intent == "report":    return await self._handle_report()
        if intent == "portfolio": return await self._handle_portfolio()
        if intent == "analyze":   return await self._handle_analyze(symbol or "BTC/USDT")
        if intent == "buy":       return await self._handle_trade("BUY",  symbol, message)
        if intent == "sell":      return await self._handle_trade("SELL", symbol, message)

        # Claude-powered: contextual routing + tool-use response
        return await self._handle_with_claude(message, symbol)

    # ── specialized handlers (unchanged logic, same as before) ───
    async def _handle_train(self) -> dict:
        if not self._hourly_trainer:
            if self._trader:
                ok = self._trader._trainer.train()
                return {"type": "train", "reply": f"เทรน ML model {'สำเร็จ ✓' if ok else 'ไม่สำเร็จ — ต้องการข้อมูลเพิ่ม'}"}
            return {"type": "error", "reply": "Trainer ไม่พร้อมใช้งาน"}
        try:
            result = await self._hourly_trainer.run_now()
            added = result.get("last_samples", 0)
            acc = result.get("model_accuracy")
            acc_str = f" | Acc: {acc*100:.1f}%" if acc else ""
            return {"type": "train", "reply": f"เทรน AI สำเร็จ ✓\nเพิ่มข้อมูล {added} samples{acc_str}"}
        except Exception as e:
            return {"type": "error", "reply": f"เทรนไม่สำเร็จ: {e}"}

    async def _handle_report(self) -> dict:
        db = SessionLocal()
        try:
            closed = db.query(Trade).filter(Trade.status == "closed").all()
            if not closed:
                return {"type": "report", "reply": "ยังไม่มีการเทรดที่ปิดแล้ว"}
            wins = [t for t in closed if (t.pnl or 0) > 0]
            total_pnl = sum(t.pnl or 0 for t in closed)
            win_rate = len(wins) / len(closed) * 100
            avg_pnl = sum(t.pnl_pct or 0 for t in closed) / len(closed)
            recent = sorted(closed, key=lambda t: t.closed_at or datetime.min, reverse=True)[:5]
            recent_lines = "\n".join(
                f"  {'✅' if (t.pnl or 0) > 0 else '❌'} {t.symbol} {t.side} {t.pnl_pct:+.2f}%"
                for t in recent if t.pnl_pct is not None
            )
            reply = (
                f"สรุปผลการเทรด\n"
                f"ทั้งหมด: {len(closed)} trades | Win: {win_rate:.1f}%\n"
                f"PnL รวม: {total_pnl:+.2f} USDT | เฉลี่ย: {avg_pnl:+.2f}%\n\n"
                f"5 ล่าสุด:\n{recent_lines or '  (ไม่มี)'}"
            )
            return {"type": "report", "reply": reply}
        finally:
            db.close()

    async def _handle_portfolio(self) -> dict:
        if not self._trader:
            return {"type": "error", "reply": "Trader ไม่พร้อมใช้งาน"}
        try:
            quote = self._trader._exchange.quote_currency
            balances = await self._trader._exchange.get_balance()
            cash_bal = balances.get(quote)
            cash = float(cash_bal.free) if cash_bal else 0.0
            total = cash
            lines = []
            for sym, analysis in self._trader.analyses.items():
                base = sym.split("/")[0]
                bal = balances.get(base)
                if bal and bal.total > 0:
                    value = bal.total * analysis.price
                    total += value
                    lines.append(f"  {base}: {bal.total:.6f} ({value:.2f} {quote})")
            pos_text = "\n".join(lines) if lines else "  ไม่มี open position"
            reply = f"พอร์ตโฟลิโอ\nCash: {cash:.2f} {quote}\nTotal: {total:.2f} {quote}\n\nPositions:\n{pos_text}"
            return {"type": "portfolio", "reply": reply}
        except Exception as e:
            return {"type": "error", "reply": f"ดึงข้อมูลพอร์ตไม่ได้: {e}"}

    async def _handle_analyze(self, symbol: str) -> dict:
        if not self._trader:
            return {"type": "error", "reply": "Trader ไม่พร้อมใช้งาน"}
        analysis = await self._trader.analyze_symbol(symbol)
        if not analysis:
            return {"type": "error", "reply": f"วิเคราะห์ {symbol} ไม่ได้"}
        portfolio = await self._trader._get_portfolio_summary()
        signal = await self._trader._get_final_signal(analysis, portfolio)
        reply = (
            f"วิเคราะห์ {symbol}\n"
            f"ราคา: ${analysis.price:.4f} ({analysis.change_24h:+.2f}%)\n"
            f"RSI: {analysis.rsi:.1f} | EMA: {analysis.ema_trend} | MACD: {analysis.macd_trend}\n"
            f"Bollinger: {analysis.bb_signal} | Volatility: {analysis.volatility}\n"
            f"สัญญาณ: {signal.action} (conf {signal.confidence:.0%})\n"
            f"เหตุผล: {signal.reasoning[:220]}"
        )
        return {"type": "analysis", "reply": reply, "signal": signal.action}

    async def _handle_trade(self, action: str, symbol: Optional[str], message: str) -> dict:
        if not self._trader:
            return {"type": "error", "reply": "Trader ไม่พร้อมใช้งาน"}
        if not symbol:
            return {"type": "info", "reply": f"กรุณาระบุเหรียญ เช่น '{action.lower()} BTC'"}
        analysis = await self._trader.analyze_symbol(symbol)
        if not analysis:
            return {"type": "error", "reply": f"ดึงข้อมูล {symbol} ไม่ได้"}
        portfolio = await self._trader._get_portfolio_summary()
        signal = await self._trader._get_final_signal(analysis, portfolio)
        if signal.action == action:
            executed = await self._trader._execute_trade(symbol, signal, analysis)
            if executed:
                return {"type": "trade", "reply": f"✓ ส่งคำสั่ง {action} {symbol} @ ${analysis.price:.4f} (conf {signal.confidence:.0%})\n{signal.reasoning[:180]}"}
            return {"type": "info", "reply": f"AI เห็นด้วยกับ {action} {symbol} แต่ไม่ execute (ติด risk limit / เงินไม่พอ / มี position อยู่แล้ว)"}
        return {"type": "info", "reply": f"AI แนะนำ {signal.action} สำหรับ {symbol} (conf {signal.confidence:.0%})\nไม่ตรงกับ {action} — จึงไม่ execute\nเหตุผล: {signal.reasoning[:180]}"}

    # ── Claude-powered handler ───────────────────────────────────
    async def _build_market_context(self) -> dict:
        """Snapshot of live market data + model stats for Claude's system prompt."""
        ctx: dict = {"market": {}, "model": {}, "recent_trades": [], "mode": "demo"}
        if not self._trader:
            return ctx
        try:
            ctx["mode"] = getattr(self._trader._exchange, "name", "demo")
            for sym, analysis in self._trader.analyses.items():
                ctx["market"][sym] = {
                    "price":     round(analysis.price, 4),
                    "change_24h": round(analysis.change_24h, 2),
                    "rsi":       round(analysis.rsi, 1) if analysis.rsi else None,
                    "signal":    analysis.overall_signal,
                    "ema_trend": analysis.ema_trend,
                }
            stats = self._trader._trainer.stats
            ctx["model"] = {
                "version":      stats.get("model_version", 0),
                "cv_accuracy":  stats.get("accuracy"),
                "val_accuracy": stats.get("val_accuracy"),
                "samples":      stats.get("total_records", 0),
                "ready":        stats.get("model_ready", False),
            }
        except Exception:
            pass
        db = SessionLocal()
        try:
            recent = (
                db.query(Trade)
                .filter(Trade.status == "closed")
                .order_by(Trade.opened_at.desc())
                .limit(5)
                .all()
            )
            ctx["recent_trades"] = [
                {"symbol": t.symbol, "side": t.side, "pnl_pct": t.pnl_pct}
                for t in recent if t.pnl_pct is not None
            ]
        finally:
            db.close()
        return ctx

    _CHAT_TOOLS = [
        {
            "name": "analyze_symbol",
            "description": (
                "วิเคราะห์เหรียญ crypto แบบละเอียด: ราคา, RSI, MACD, EMA, Bollinger, "
                "ความผันผวน และสัญญาณ AI สำหรับการซื้อขาย"
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "symbol": {
                        "type": "string",
                        "description": "Trading pair เช่น BTC/USDT, ETH/USDT, SOL/USDT"
                    }
                },
                "required": ["symbol"],
            },
        },
        {
            "name": "get_performance_report",
            "description": "ดูสถิติผลการเทรดทั้งหมด: win rate, กำไร/ขาดทุน, ประวัติ",
            "input_schema": {"type": "object", "properties": {}},
        },
        {
            "name": "get_portfolio",
            "description": "ดูยอดเงินปัจจุบันและ position ที่ถืออยู่ในพอร์ต",
            "input_schema": {"type": "object", "properties": {}},
        },
    ]

    async def _exec_chat_tool(self, name: str, params: dict) -> dict:
        if name == "analyze_symbol":
            symbol = params.get("symbol", "BTC/USDT")
            if not self._trader:
                return {"error": "Trader ไม่พร้อม"}
            analysis = await self._trader.analyze_symbol(symbol)
            if not analysis:
                return {"error": f"วิเคราะห์ {symbol} ไม่ได้"}
            portfolio = await self._trader._get_portfolio_summary()
            signal = await self._trader._get_final_signal(analysis, portfolio)
            return {
                "symbol":     symbol,
                "price":      round(analysis.price, 4),
                "change_24h": round(analysis.change_24h, 2),
                "rsi":        round(analysis.rsi, 1) if analysis.rsi else None,
                "ema_trend":  analysis.ema_trend,
                "macd_trend": analysis.macd_trend,
                "bb_signal":  analysis.bb_signal,
                "volatility": analysis.volatility,
                "signal":     signal.action,
                "confidence": round(signal.confidence, 3),
                "reasoning":  signal.reasoning[:300],
            }

        if name == "get_performance_report":
            db = SessionLocal()
            try:
                closed = db.query(Trade).filter(Trade.status == "closed").all()
                if not closed:
                    return {"message": "ยังไม่มีการเทรดที่ปิดแล้ว"}
                wins = [t for t in closed if (t.pnl or 0) > 0]
                total_pnl = sum(t.pnl or 0 for t in closed)
                win_rate  = len(wins) / len(closed) * 100
                avg_pct   = sum(t.pnl_pct or 0 for t in closed) / len(closed)
                recent    = sorted(closed, key=lambda t: t.closed_at or datetime.min, reverse=True)[:5]
                return {
                    "total_trades": len(closed),
                    "wins":         len(wins),
                    "win_rate_pct": round(win_rate, 1),
                    "total_pnl":    round(total_pnl, 2),
                    "avg_pnl_pct":  round(avg_pct, 2),
                    "recent":       [{"symbol": t.symbol, "side": t.side, "pnl_pct": t.pnl_pct} for t in recent if t.pnl_pct is not None],
                }
            finally:
                db.close()

        if name == "get_portfolio":
            if not self._trader:
                return {"error": "Trader ไม่พร้อม"}
            try:
                quote    = self._trader._exchange.quote_currency
                balances = await self._trader._exchange.get_balance()
                cash_bal = balances.get(quote)
                cash     = float(cash_bal.free) if cash_bal else 0.0
                positions = []
                for sym, analysis in self._trader.analyses.items():
                    base = sym.split("/")[0]
                    bal  = balances.get(base)
                    if bal and bal.total > 0:
                        positions.append({
                            "asset":    base,
                            "amount":   round(bal.total, 6),
                            "value":    round(bal.total * analysis.price, 2),
                            "currency": quote,
                        })
                return {"cash": round(cash, 2), "currency": quote, "positions": positions}
            except Exception as e:
                return {"error": str(e)}

        return {"error": f"Unknown tool: {name}"}

    async def _handle_with_claude(self, message: str, hint_symbol: Optional[str]) -> dict:
        """Invoke Claude with live context, conversation memory, and tool use."""
        import json
        api_key = settings.claude_api_key
        if not api_key:
            return {
                "type": "info",
                "reply": (
                    "คำสั่งที่รองรับ:\n"
                    "• ซื้อ/ขาย BTC ETH SOL XRP BNB\n"
                    "• วิเคราะห์ BTC\n"
                    "• รายงานผล / สรุปผล\n"
                    "• พอร์ตฉัน\n"
                    "• เทรนตัวเอง\n\n"
                    "ตั้งค่า Claude API key ใน Settings → AI เพื่อเปิดการสนทนาอัจฉริยะ"
                ),
            }

        # Serialise concurrent requests so history append→read→write stays consistent.
        async with _get_chat_lock():
            try:
                import anthropic
                client = anthropic.AsyncAnthropic(api_key=api_key)
                ctx = await self._build_market_context()

                market_lines = "\n".join(
                    f"  {sym}: ${d['price']} ({d['change_24h']:+.2f}%) RSI={d['rsi']} signal={d['signal']}"
                    for sym, d in ctx["market"].items()
                ) or "  (ยังไม่มีข้อมูล)"

                trade_lines = "\n".join(
                    f"  {t['symbol']} {t['side']} {t['pnl_pct']:+.2f}%"
                    for t in ctx["recent_trades"]
                ) or "  (ยังไม่มี)"

                m = ctx["model"]
                model_line = (
                    f"v{m['version']} | CV={m['cv_accuracy'] or '—'} | "
                    f"Val={m['val_accuracy'] or '—'} | samples={m['samples']} | "
                    f"ready={'✓' if m['ready'] else '✗'}"
                )

                sys_prompt = (
                    "คุณคือ Aiterra AI Trading Assistant — ผู้ช่วยการเทรด Crypto ที่ฉลาดและเป็นมืออาชีพ\n"
                    "ตอบเป็นภาษาไทยเสมอ กระชับ ชัดเจน ไม่ใช้ markdown symbols (* # _)\n"
                    "ถ้าผู้ใช้ถามเรื่องเหรียญหรือตลาด ให้เรียก tool analyze_symbol เพื่อดูข้อมูลล่าสุดก่อนตอบ\n\n"
                    f"=== ข้อมูลตลาด ณ ตอนนี้ ===\n{market_lines}\n\n"
                    f"=== AI Model ===\n{model_line}\n\n"
                    f"=== การเทรดล่าสุด ===\n{trade_lines}\n\n"
                    f"=== Exchange ===\n{ctx['mode']}"
                )

                # Append user turn to history
                ChatHandler._history.append({"role": "user", "content": message})
                if len(ChatHandler._history) > self.MAX_HISTORY:
                    ChatHandler._history = ChatHandler._history[-self.MAX_HISTORY:]

                # Working copy for this request's tool-call loop
                loop_msgs = list(ChatHandler._history)

                for _step in range(self.MAX_TOOL_STEPS):
                    resp = await client.messages.create(
                        model=settings.claude_model,
                        max_tokens=1024,
                        system=sys_prompt,
                        tools=self._CHAT_TOOLS,
                        messages=loop_msgs,
                    )

                    tool_uses = [b for b in resp.content if b.type == "tool_use"]

                    if resp.stop_reason == "end_turn" or not tool_uses:
                        text = " ".join(b.text for b in resp.content if b.type == "text").strip()
                        if text:
                            ChatHandler._history.append({"role": "assistant", "content": text})
                            if len(ChatHandler._history) > self.MAX_HISTORY:
                                ChatHandler._history = ChatHandler._history[-self.MAX_HISTORY:]
                        return {"type": "ai", "reply": text or "—"}

                    # Build serialisable assistant content (tool_use blocks)
                    assistant_content = []
                    for b in resp.content:
                        if b.type == "text":
                            assistant_content.append({"type": "text", "text": b.text})
                        elif b.type == "tool_use":
                            assistant_content.append({
                                "type": "tool_use",
                                "id":    b.id,
                                "name":  b.name,
                                "input": b.input,
                            })

                    # Execute tools and collect results
                    tool_results = []
                    for tu in tool_uses:
                        result = await self._exec_chat_tool(tu.name, tu.input)
                        tool_results.append({
                            "type":        "tool_result",
                            "tool_use_id": tu.id,
                            "content":     json.dumps(result, ensure_ascii=False, default=str),
                        })

                    loop_msgs.append({"role": "assistant", "content": assistant_content})
                    loop_msgs.append({"role": "user",      "content": tool_results})

                return {"type": "info", "reply": "ไม่สามารถตอบได้ในขณะนี้ กรุณาลองใหม่"}

            except Exception as e:
                logger.warning(f"Chat Claude error: {e}")
                return {
                    "type": "info",
                    "reply": (
                        "คำสั่งที่รองรับ:\n"
                        "• ซื้อ/ขาย BTC ETH SOL XRP BNB\n"
                        "• วิเคราะห์ BTC\n"
                        "• รายงานผล\n"
                        "• พอร์ตฉัน\n"
                        "• เทรนตัวเอง"
                    ),
                }

    @classmethod
    def clear_history(cls):
        cls._history.clear()


@router.post("/chat")
async def chat_endpoint(data: Dict[str, Any]):
    """POST /api/chat — Natural language command interface for the AI trading agent."""
    message = (data.get("message") or "").strip()
    if not message:
        raise HTTPException(400, "message required")
    handler = ChatHandler(_trader, _hourly_trainer)
    return await handler.handle(message)


@router.post("/chat/clear")
async def chat_clear():
    """POST /api/chat/clear — Clear conversation history."""
    ChatHandler.clear_history()
    return {"ok": True}


@router.get("/exchanges/test")
async def test_exchanges():
    """GET /api/exchanges/test — Ping configured exchanges and return status."""
    results = {}

    # Always test demo (should always work)
    if _trader and _trader._exchange:
        try:
            ticker = await _trader._exchange.get_ticker("BTC/USDT")
            results["demo"] = {"ok": True, "price": ticker.price, "source": "live" if ticker.price > 1000 else "simulated"}
        except Exception as e:
            results["demo"] = {"ok": False, "error": str(e)}

    # Test each configured live exchange (single source of truth = factory)
    from ..exchanges import LIVE_EXCHANGES, has_credentials
    from ..exchanges.factory import _load
    for name in LIVE_EXCHANGES:
        cfg = settings.get("exchanges", name) or {}
        if not cfg.get("enabled") or not has_credentials(name):
            results[name] = {"ok": None, "status": "not_configured"}
            continue
        # THB venues quote against THB, not USDT — probe a symbol they list.
        probe = "BTC/THB" if name in ("bitkub", "binance_th") else "BTC/USDT"
        client = None
        try:
            client = _load(name)
            ticker = await client.get_ticker(probe)
            results[name] = {"ok": True, "price": ticker.price}
        except Exception as e:
            results[name] = {"ok": False, "error": str(e)[:120]}
        finally:
            if client is not None and hasattr(client, "close"):
                try:
                    await client.close()
                except Exception:
                    pass

    return results


# ─── Notification Test ─────────────────────────────────────────

@router.post("/notifications/test")
async def test_notifications(data: Dict[str, Any] = None):
    """Send a test message to configured LINE / Telegram channels."""
    msg = "🧪 Aiterra — การแจ้งเตือนทดสอบ / Test notification ✅"
    results = {}

    # LINE Messaging API
    line_id     = settings.get("notifications", "line", "channel_id",     default="")
    line_secret = settings.get("notifications", "line", "channel_secret", default="")
    if line_id and line_secret:
        try:
            import aiohttp
            # 1. Get channel access token
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "https://api.line.me/v2/oauth/accessToken",
                    data={"grant_type": "client_credentials",
                          "client_id": line_id, "client_secret": line_secret},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as tr:
                    tr.raise_for_status()
                    access_token = (await tr.json())["access_token"]
            # 2. Send message (push if user_id set, broadcast otherwise)
            user_id = settings.get("notifications", "line", "user_id", default="")
            headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
            body = {"messages": [{"type": "text", "text": msg}]}
            url = "https://api.line.me/v2/bot/message/push" if user_id else "https://api.line.me/v2/bot/message/broadcast"
            if user_id:
                body["to"] = user_id
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=body,
                                        timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status in (200, 201):
                        results["line"] = {"ok": True}
                    else:
                        body_text = await resp.text()
                        results["line"] = {"ok": False, "error": f"HTTP {resp.status}: {body_text[:120]}"}
        except Exception as e:
            results["line"] = {"ok": False, "error": str(e)[:120]}
    else:
        results["line"] = {"ok": None, "status": "not_configured"}

    # Telegram
    tg_token   = settings.get("notifications", "telegram", "bot_token", default="")
    tg_chat_id = settings.get("notifications", "telegram", "chat_id", default="")
    if tg_token and tg_chat_id:
        try:
            import aiohttp
            url = f"https://api.telegram.org/bot{tg_token}/sendMessage"
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url,
                    json={"chat_id": tg_chat_id, "text": msg},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    body = await resp.json()
                    if resp.status == 200 and body.get("ok"):
                        results["telegram"] = {"ok": True}
                    else:
                        results["telegram"] = {"ok": False, "error": body.get("description", f"HTTP {resp.status}")[:120]}
        except Exception as e:
            results["telegram"] = {"ok": False, "error": str(e)[:120]}
    else:
        results["telegram"] = {"ok": None, "status": "not_configured"}

    return results


# ─── Live Mode Hot-Swap ────────────────────────────────────────

@router.post("/mode/swap")
async def hot_swap_mode(data: Dict[str, str], _=_AUTH):
    """POST /api/mode/swap — switch demo↔live without restarting the server.

    For live mode the first *enabled* exchange with an api_key is used.
    Returns the new mode and exchange name, or an error if no live exchange
    is configured when switching to live.
    """
    mode = data.get("mode", "demo")
    if mode not in ("demo", "live"):
        raise HTTPException(400, "mode must be 'demo' or 'live'")

    if not _trader:
        raise HTTPException(503, "Trader not running")

    from ..exchanges import DemoExchange, create_live_exchange_strict, LiveExchangeError

    if mode == "demo":
        new_exchange = DemoExchange()
        exchange_name = "demo"
    else:
        try:
            new_exchange, exchange_name = create_live_exchange_strict()
        except LiveExchangeError as e:
            raise HTTPException(400, str(e))

    # Refuse to abandon real open positions on a live→demo (or live→live) switch.
    if not _trader._exchange.is_demo and _trader._open_trades:
        raise HTTPException(
            409,
            f"Close your {len(_trader._open_trades)} open live position(s) before switching modes."
        )

    # Close old exchange if it has a close() method
    old_exchange = _trader._exchange
    try:
        if hasattr(old_exchange, "close"):
            await old_exchange.close()
    except Exception:
        pass

    # Swap in the new exchange — hot-swap while the trader loop keeps running.
    _trader._exchange = new_exchange
    _trader._claude.set_exchange(new_exchange)   # Claude tool-calls must hit the new exchange
    _trader._analyses.clear()                    # stale prices from the old exchange
    _trader._open_trades.clear()                 # positions belong to the previous exchange/mode
    _trader._daily_pnl = 0.0                      # realized PnL is per-exchange
    settings.set(mode, "trading", "mode")
    settings.save()

    logger.info(f"Hot-swapped to {mode} mode (exchange: {exchange_name})")
    await _trader._broadcast("mode_changed", {"mode": mode, "exchange": exchange_name})

    return {"mode": mode, "exchange": exchange_name, "swapped": True}


@router.get("/exchange/active")
async def get_active_exchange():
    """GET /api/exchange/active — which live exchange is selected and which would
    actually be used (resolved), plus the live-readiness of each exchange."""
    from ..exchanges import LIVE_EXCHANGES, has_credentials, resolve_live_exchange
    status = {}
    for name in LIVE_EXCHANGES:
        cfg = settings.get("exchanges", name) or {}
        status[name] = {
            "enabled": bool(cfg.get("enabled")),
            "has_keys": has_credentials(name),
            "ready": bool(cfg.get("enabled")) and has_credentials(name),
        }
    return {
        "active": settings.get("exchanges", "active", default=""),
        "resolved": resolve_live_exchange(),   # what live mode would actually use
        "current": _trader._exchange.name if _trader else None,
        "mode": settings.trading_mode,
        "exchanges": status,
    }


@router.post("/exchange/active")
async def set_active_exchange(data: Dict[str, str], _=_AUTH):
    """POST /api/exchange/active — choose which live exchange to trade on.
    Body: {"exchange": "binance"|"binance_th"|"bitkub"|"okx"}
    Does not switch mode; call /api/mode/swap to go live.
    """
    from ..exchanges import LIVE_EXCHANGES
    name = (data.get("exchange") or "").strip()
    if name not in LIVE_EXCHANGES:
        raise HTTPException(400, f"exchange must be one of {list(LIVE_EXCHANGES)}")
    settings.set(name, "exchanges", "active")
    settings.save()
    return {"active": name}


# ─── One-click live trading (guarded) ──────────────────────────

@router.post("/live/start")
async def live_start(data: Dict[str, Any], _=_AUTH):
    """POST /api/live/start — one-click "Start AI Live Trading" with guardrails.

    Body: {"confirm": "LIVE", "budget_usdt": <number>}

    Steps, in order, aborting on the first failure:
      1. Require the user to type LIVE  (typo guard)
      2. Require a positive budget cap   (spending guard)
      3. Test the live exchange connection (keys + connectivity)
      4. Apply the budget cap, hot-swap to live, un-pause auto-trading
    """
    if not _trader:
        raise HTTPException(503, "Trader not running")

    # 1) typed confirmation
    if str(data.get("confirm", "")).strip().upper() != "LIVE":
        raise HTTPException(400, 'Type LIVE to confirm real-money trading.')

    # 2) budget cap (initial spending limit)
    try:
        budget = float(data.get("budget_usdt", 0))
    except (TypeError, ValueError):
        budget = 0.0
    if budget < 10:
        raise HTTPException(400, "Set a starting budget of at least 10 USDT.")

    from ..exchanges import create_live_exchange_strict, LiveExchangeError

    # 3) build + TEST the live exchange before committing anything
    try:
        new_exchange, exchange_name = create_live_exchange_strict()
    except LiveExchangeError as e:
        raise HTTPException(400, str(e))

    try:
        balances = await new_exchange.get_balance()
        quote = new_exchange.quote_currency
        cash = balances.get(quote)
        free_cash = float(cash.free) if cash else 0.0
    except Exception as e:
        try:
            if hasattr(new_exchange, "close"):
                await new_exchange.close()
        except Exception:
            pass
        raise HTTPException(400, f"Connection test failed for {exchange_name}: {e}")

    # Refuse to abandon real open positions on the current live exchange.
    if not _trader._exchange.is_demo and _trader._open_trades:
        raise HTTPException(
            409,
            f"Close your {len(_trader._open_trades)} open live position(s) first."
        )

    # 4) commit: budget cap → swap → un-pause
    settings.set(budget, "trading", "live_max_budget_usdt")
    settings.set("live", "trading", "mode")
    settings.save()

    old_exchange = _trader._exchange
    try:
        if hasattr(old_exchange, "close"):
            await old_exchange.close()
    except Exception:
        pass

    _trader._exchange = new_exchange
    _trader._claude.set_exchange(new_exchange)
    _trader._analyses.clear()
    _trader._open_trades.clear()
    _trader._daily_pnl = 0.0
    _trader._paused = False

    logger.warning(f"LIVE trading started on {exchange_name} (budget cap {budget} USDT)")
    await _trader._broadcast("mode_changed", {"mode": "live", "exchange": exchange_name})

    return {
        "ok": True,
        "mode": "live",
        "exchange": exchange_name,
        "budget_usdt": budget,
        "free_cash": round(free_cash, 2),
        "quote": quote,
    }


@router.post("/live/stop")
async def live_stop(_=_AUTH):
    """POST /api/live/stop — KILL SWITCH.

    Immediately pauses all new entries, then returns to demo mode if no live
    positions are open. Protective exits (SL/TP/trailing) on any remaining
    live positions keep running; close them manually to fully exit.
    """
    if not _trader:
        raise HTTPException(503, "Trader not running")

    # Pause first — this always takes effect instantly, blocking new BUYs.
    _trader._paused = True

    open_live = (not _trader._exchange.is_demo) and bool(_trader._open_trades)
    swapped = False
    if not open_live:
        from ..exchanges import DemoExchange
        old_exchange = _trader._exchange
        try:
            if hasattr(old_exchange, "close"):
                await old_exchange.close()
        except Exception:
            pass
        _trader._exchange = DemoExchange()
        _trader._claude.set_exchange(_trader._exchange)
        _trader._analyses.clear()
        _trader._open_trades.clear()
        _trader._daily_pnl = 0.0
        settings.set("demo", "trading", "mode")
        settings.save()
        swapped = True
        # Back on safe (virtual) demo money — let normal demo auto-trading resume.
        _trader._paused = False
        await _trader._broadcast("mode_changed", {"mode": "demo", "exchange": "demo"})

    logger.warning("KILL SWITCH activated — live entries halted" +
                   (" and switched back to demo" if swapped else " (live positions still open)"))
    return {
        "ok": True,
        "paused": True,
        "mode": settings.trading_mode,
        "switched_to_demo": swapped,
        "open_live_positions": len(_trader._open_trades) if open_live else 0,
    }


@router.get("/live/status")
async def live_status():
    """GET /api/live/status — live-trading state for the dashboard control."""
    from ..exchanges import resolve_live_exchange, has_credentials
    deployed = 0.0
    if _trader:
        deployed = sum(t.get("cost", 0) or 0 for t in _trader._open_trades.values())
    resolved = resolve_live_exchange()
    return {
        "mode": settings.trading_mode,
        "is_live": bool(_trader and not _trader._exchange.is_demo) if _trader else False,
        "paused": bool(_trader._paused) if _trader else False,
        "running": bool(_trader._running) if _trader else False,
        "budget_usdt": float(settings.get("trading", "live_max_budget_usdt", default=0) or 0),
        "deployed_usdt": round(deployed, 2),
        "open_positions": len(_trader._open_trades) if _trader else 0,
        "resolved_exchange": resolved,
        "live_ready": bool(resolved and has_credentials(resolved)),
    }

